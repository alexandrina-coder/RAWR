import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Minus } from 'lucide-react';

export default function FAQ() {
  const faqs = [
    {
      q: "Est-ce que l’IA remplace mon équipe ?",
      a: "Non. RAWR automatise les tâches répétitives (relances, requêtes prix, prises de RDV simples) pour permettre à votre équipe de se libérer du téléphone et de se concentrer sur l’excellence de l'expérience client et les prestations en elles-mêmes."
    },
    {
      q: "Est-ce compatible avec mes outils actuels ?",
      a: "Oui, RAWR peut être connecté à de nombreux outils comme WhatsApp, email, Instagram, Calendly, Planity, Doctolib, Treatwell, Google Sheets, CRM et autres systèmes selon votre configuration technique. Nous l'analyserons lors de l'audit."
    },
    {
      q: "Combien de temps prend l’installation ?",
      a: "Cela dépend du niveau d’automatisation souhaité. Après l’audit, RAWR vous propose un plan d'action clair avec les étapes de mise en place, allant de quelques jours pour une IA basique à quelques semaines pour un CRM complet."
    },
    {
      q: "Est-ce adapté aux petites structures ?",
      a: "Absolument. Les automatisations sont modulables et peuvent être parfaitement adaptées aux instituts indépendants, petits salons de quartier comme aux très grandes cliniques."
    },
    {
      q: "Puis-je commencer avec une seule automatisation ?",
      a: "Oui. Vous pouvez très bien commencer par une automatisation prioritaire, comme par exemple la gestion des relances Instagram, ou les rappels anti no-show, puis évoluer plus tard."
    }
  ];

  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section id="faq" className="py-24 bg-white">
      <div className="max-w-3xl mx-auto px-4 md:px-8">
        
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-serif">Vos questions fréquentes</h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <div key={i} className="border border-rawr-muted rounded-[8px] overflow-hidden bg-rawr-bg">
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-6 text-left focus:outline-none"
              >
                <span className="font-semibold">{faq.q}</span>
                {openIndex === i ? (
                  <Minus className="w-5 h-5 text-rawr-accent shrink-0" />
                ) : (
                  <Plus className="w-5 h-5 text-rawr-ink/50 shrink-0" />
                )}
              </button>
              
              <AnimatePresence>
                {openIndex === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="px-6 pb-6 text-rawr-ink/70 text-sm leading-relaxed border-t border-black/5 pt-4">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
