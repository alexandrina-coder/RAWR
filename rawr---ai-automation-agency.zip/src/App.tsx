import React, { useEffect, useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import PainPoints from './components/PainPoints';
import Transformation from './components/Transformation';
import Solutions from './components/Solutions';
import UseCases from './components/UseCases';
import Benefits from './components/Benefits';
import Results from './components/Results';
import Process from './components/Process';
import Offer from './components/Offer';
import LeadForm from './components/LeadForm';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import GDPR from './components/GDPR';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="relative min-h-screen bg-rawr-bg text-rawr-ink font-sans">
      <Header />
      <main>
        <Hero />
        <PainPoints />
        <Transformation />
        <Solutions />
        <UseCases />
        <Benefits />
        <Results />
        <Process />
        <Offer />
        <LeadForm />
        <Testimonials />
        <FAQ />
        <GDPR />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}

