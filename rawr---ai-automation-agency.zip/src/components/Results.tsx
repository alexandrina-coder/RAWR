import React from 'react';
import { motion } from 'motion/react';

export default function Results() {
  const metrics = [
    { value: "-90%", label: "Temps de réponse client" },
    { value: "+35%", label: "Taux de conversion des prospects (estimé)" },
    { value: "-50%", label: "De no-shows grâce aux rappels proactifs" },
    { value: "+40%", label: "D'avis Google en moyenne après 3 mois" },
  ];

  return (
    <section id="resultats" className="py-24 bg-rawr-bg">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-3xl md:text-5xl font-serif mb-6 leading-tight">
            Des systèmes pensés pour <span className="italic">améliorer vos chiffres.</span>
          </h2>
          <p className="text-sm text-rawr-ink/60 max-w-xl mx-auto uppercase tracking-wide font-medium">
            Objectifs possibles selon votre volume actuel, vos offres et votre système de réservation.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 divide-x divide-rawr-muted">
          {metrics.map((m, i) => (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              key={i}
              className="text-center px-4"
            >
              <div className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-rawr-accent mb-4">
                {m.value}
              </div>
              <div className="text-sm font-medium text-rawr-ink/70">
                {m.label}
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
