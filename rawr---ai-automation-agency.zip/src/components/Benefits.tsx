import React from 'react';
import { motion } from 'motion/react';
import { Plus, MessageSquare, AlertCircle, Star, Heart, Image as ImageIcon, Settings } from 'lucide-react';

export default function Benefits() {
  const benefitsList = [
    { text: "Plus de rendez-vous", icon: <Plus className="w-4 h-4 text-rawr-ink" strokeWidth={2.5} /> },
    { text: "Moins de messages", icon: <MessageSquare className="w-4 h-4 text-[#8b0000]" /> },
    { text: "Moins de no-shows", icon: <AlertCircle className="w-4 h-4 text-[#8b0000]" /> },
    { text: "Plus d'avis", icon: <Star className="w-4 h-4 text-rawr-ink" strokeWidth={1.5} /> },
    { text: "Plus de clients fidèles", icon: <Heart className="w-4 h-4 text-[#8b0000]" strokeWidth={1.5} /> },
    { text: "Meilleure image", icon: <ImageIcon className="w-4 h-4 text-[#8b0000]" /> },
    { text: "Équipe productive", icon: <Settings className="w-4 h-4 text-rawr-ink" /> },
  ];

  const metrics = [
    { label: "Temps de réponse réduit", value: "-95%" },
    { label: "Conversion prospects", value: "+40%" },
    { label: "Réduction des no-shows", value: "-65%" },
    { label: "Avis Google augmentés", value: "x3" },
  ];

  return (
    <section className="py-24 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid lg:grid-cols-[1fr_450px] xl:grid-cols-[1fr_500px] gap-16 items-center">
          
          {/* Left Column */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-[46px] font-sans font-black tracking-tight mb-6 text-rawr-ink leading-[1.1]">
              Ce que RAWR peut changer dans votre business
            </h2>
            <p className="text-lg text-rawr-ink/80 mb-10 leading-relaxed font-sans max-w-xl">
              L'IA ne remplace pas votre équipe. Elle la rend <span className="border-b-[2px] border-[#9F1239] text-rawr-ink font-medium">redoutablement efficace</span> en gérant le "bruit" administratif pour qu'elle se concentre sur l'humain.
            </p>

            <div className="grid sm:grid-cols-2 gap-4">
              {benefitsList.map((item, i) => (
                <div key={i} className="flex items-center space-x-4 bg-[#F9F7F5] border border-black/5 rounded-xl px-5 py-4">
                  <div className="w-4 flex items-center justify-center shrink-0">
                    {item.icon}
                  </div>
                  <span className="text-[14px] font-bold text-rawr-ink font-sans tracking-wide">{item.text}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Right Column (Card) */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-[linear-gradient(135deg,#7B0728_0%,#1a0510_100%)] text-white rounded-[32px] p-10 md:p-14 shadow-2xl relative overflow-hidden w-full"
          >
            <h3 className="text-2xl md:text-[28px] leading-tight font-sans font-bold italic text-center mb-10">
              Des systèmes pensés pour améliorer vos chiffres
            </h3>

            <div className="space-y-6 mb-12">
              {metrics.map((m, i) => (
                <div key={i} className="flex justify-between items-center border-b border-white/10 pb-5">
                  <span className="text-[15px] text-white/90 font-medium font-sans">{m.label}</span>
                  <span className="text-2xl font-bold font-sans">{m.value}</span>
                </div>
              ))}
            </div>

            <p className="text-center text-[10px] uppercase tracking-[0.15em] text-white/50 font-sans font-medium">
              Objectifs possibles selon votre activité
            </p>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
