import React from 'react';

export default function FinalCTA() {
  return (
    <section className="py-32 bg-rawr-ink text-white text-center px-4">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl md:text-6xl font-serif mb-6 leading-tight">
          Votre prochain client ne devrait <span className="italic text-rawr-accent-light">jamais attendre une réponse.</span>
        </h2>
        <p className="text-lg md:text-xl opacity-80 mb-12 max-w-2xl mx-auto font-light">
          RAWR installe les automatisations IA qui transforment vos demandes en rendez-vous, vos clients en habitués, et votre équipe en machine à performance.
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
          <a
            href="#audit"
            className="w-full sm:w-auto text-center inline-block bg-white text-rawr-ink px-8 py-4 rounded-[4px] text-[12px] uppercase tracking-[0.5px] font-medium hover:bg-rawr-bg transition-colors"
          >
            Réserver un audit gratuit
          </a>
          <a
            href="#faq"
            className="w-full sm:w-auto text-center inline-block bg-transparent border border-white/30 text-white px-8 py-4 rounded-[4px] text-[12px] uppercase tracking-[0.5px] font-medium hover:bg-white/10 transition-colors"
          >
            Parler à RAWR
          </a>
        </div>
      </div>
    </section>
  );
}
