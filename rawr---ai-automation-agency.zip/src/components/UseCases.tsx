import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Syringe, Sparkles, Scissors, Flower2, Bot } from 'lucide-react';

export default function UseCases() {
  const [activeTab, setActiveTab] = useState(0);

  const cases = [
    {
      title: "Clinique esthétique",
      icon: <Syringe className="w-5 h-5" />,
      services: "Botox, fillers, laser, épilation définitive, soins visage avancés",
      benefits: [
        "Qualification fine des demandes avant consultation médicale ou soin technique.",
        "Rappels de suivi post-traitement pour surveiller l'évolution et rassurer le patient.",
        "Relance intelligente pour les séances multiples (laser, cures)."
      ],
      color: "bg-[#f4e8e1]"
    },
    {
      title: "Salon de beauté",
      icon: <Sparkles className="w-5 h-5" />,
      services: "Ongles, cils, sourcils, soins visage, maquillage",
      benefits: [
        "Réservation ultra-rapide depuis Instagram pour des prestations impulsives.",
        "Relance post-prestation pour demander un avis Google à chaud.",
        "Offres fidélité automatisées pour les clientes régulières."
      ],
      color: "bg-[#e8ecef]"
    },
    {
      title: "Salon de coiffure",
      icon: <Scissors className="w-5 h-5" />,
      services: "Coupes, colorations, balayages, lissages, extensions",
      benefits: [
        "Rappels automatiques coupe/couleur au bout de X mois.",
        "Réactivation client automatisée après 6 à 8 semaines d'absence.",
        "Upsell automatisé sur des soins capillaires post-rendez-vous."
      ],
      color: "bg-[#ebebd3]"
    },
    {
      title: "Institut de bien-être",
      icon: <Flower2 className="w-5 h-5" />,
      services: "Massages, spa, hammam, abonnements, soins holistiques",
      benefits: [
        "Gestion fluide des abonnements et packs de soins.",
        "Relances pour l'achat de bons cadeaux aux dates clés (Noël, Fête des mères).",
        "Suivi de satisfaction automatisé pour garantir l'excellence."
      ],
      color: "bg-[#e5e1ea]"
    }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-serif mb-6 leading-tight">
            Exemples d'automatisations <span className="italic block">pour votre activité.</span>
          </h2>
        </div>

        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {cases.map((c, i) => (
            <button
              key={i}
              onClick={() => setActiveTab(i)}
              className={`flex items-center space-x-2 px-6 py-3 rounded-full text-sm font-medium transition-all ${
                activeTab === i 
                  ? 'bg-rawr-ink text-white' 
                  : 'bg-rawr-bg text-rawr-ink/70 hover:bg-rawr-bg/80 hover:text-rawr-ink'
              }`}
            >
              {c.icon}
              <span>{c.title}</span>
            </button>
          ))}
        </div>

        <div className="max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className={`${cases[activeTab].color} rounded-[8px] p-8 md:p-12 overflow-hidden relative`}
            >
              <div className="relative z-10 grid md:grid-cols-2 gap-12 items-center">
                <div>
                  <h3 className="text-3xl font-serif font-bold mb-4">{cases[activeTab].title}</h3>
                  <p className="text-sm uppercase tracking-wider font-semibold opacity-60 mb-8 block font-sans">
                    {cases[activeTab].services}
                  </p>
                  <ul className="space-y-6">
                    {cases[activeTab].benefits.map((ben, j) => (
                      <li key={j} className="flex items-start space-x-4">
                        <div className="w-2 h-2 mt-2 bg-rawr-ink rounded-full shrink-0" />
                        <span className="text-rawr-ink/90 font-medium leading-relaxed">{ben}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="relative h-full hidden md:flex items-center justify-center">
                  <div className="w-full bg-white/60 backdrop-blur-md rounded-[8px] p-6 shadow-xl border border-white/40">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 rounded-full bg-rawr-accent/20 flex flex-center items-center justify-center text-rawr-accent">
                        <Bot size={20} />
                      </div>
                      <div>
                        <div className="text-sm font-bold">Assistant RAWR</div>
                        <div className="text-xs opacity-60">Scénario actif</div>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div className="bg-white p-3 rounded-[8px] rounded-tl-none text-xs shadow-sm border border-black/5">
                        Que pouvons-nous faire pour préparer son application ? L'IA gère ça en un clin d'œil.
                      </div>
                      <div className="bg-rawr-accent text-white p-3 rounded-[8px] rounded-tr-none text-xs ml-8 shadow-sm">
                        Je souhaite réserver.
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

      </div>
    </section>
  );
}
