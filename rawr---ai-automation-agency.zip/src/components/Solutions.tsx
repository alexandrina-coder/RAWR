import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Minus } from 'lucide-react';

export default function Solutions() {
  const solutions = [
    {
      title: "Assistant IA de rendez-vous",
      desc: "Un assistant IA qui répond aux demandes clients, qualifie les prospects, propose les prestations adaptées et guide vers la réservation.",
    },
    {
      title: "Automatisation WhatsApp & SMS",
      desc: "Relancez automatiquement les prospects, confirmez les rendez-vous et envoyez des rappels personnalisés.",
    },
    {
      title: "Système anti no-show",
      desc: "Réduisez les absences grâce à des rappels automatisés et confirmations intelligentes. Reprogrammation simplifiée.",
    },
    {
      title: "Réactivation clients dormants",
      desc: "Faites revenir les anciens clients avec des campagnes intelligentes basées sur leur historique et des offres ciblées.",
    },
    {
      title: "Génération d'avis Google",
      desc: "Automatisez la demande d'avis après chaque rendez-vous satisfait pour renforcer votre réputation et visibilité locale.",
    },
    {
      title: "Automatisation IG DM",
      desc: "Transformez les conversations Instagram en rendez-vous qualifiés instantanément, qualification et envoi de prix.",
    },
    {
      title: "CRM IA Spécialisé",
      desc: "Centralisez vos prospects, clients, relances et opportunités dans un système automatisé. Pipeline clair.",
    }
  ];

  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section id="solutions" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        <div className="grid lg:grid-cols-[1fr_400px] xl:grid-cols-[1fr_500px] gap-16 items-start">
          
          <div>
            <div className="mb-12">
              <h2 className="text-4xl md:text-5xl font-serif mb-4 text-rawr-ink">
                Nos Solutions
              </h2>
              <p className="text-rawr-ink/60 text-lg">
                Des automatisations IA conçues pour les cliniques et salons.
              </p>
            </div>

            <div className="space-y-0">
              {solutions.map((sol, i) => (
                <div key={i} className="border-b border-rawr-ink/10 last:border-b-0">
                  <button
                    onClick={() => setOpenIndex(openIndex === i ? null : i)}
                    className="w-full flex items-center justify-between py-6 text-left focus:outline-none group"
                  >
                    <span className="font-serif text-xl md:text-2xl text-rawr-ink group-hover:text-rawr-accent transition-colors">{sol.title}</span>
                    {openIndex === i ? (
                      <Minus className="w-6 h-6 text-rawr-accent shrink-0" strokeWidth={1.5} />
                    ) : (
                      <Plus className="w-6 h-6 text-rawr-ink/40 group-hover:text-rawr-accent transition-colors shrink-0" strokeWidth={1.5} />
                    )}
                  </button>
                  
                  <AnimatePresence>
                    {openIndex === i && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <div className="pb-6 text-rawr-ink/70 text-[15px] leading-relaxed max-w-xl">
                          {sol.desc}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              ))}
            </div>
          </div>

          <div className="hidden lg:block relative h-full min-h-[600px] w-full">
             <div className="absolute inset-0 bg-rawr-bg overflow-hidden aspect-[3/4] lg:aspect-auto">
               <img 
                  src="https://images.unsplash.com/photo-1600334089648-b0d9d3028eb2?q=80&w=2070&auto=format&fit=crop" 
                  alt="Aesthetic professional" 
                  className="w-full h-full object-cover" 
                />
             </div>
          </div>

        </div>

      </div>
    </section>
  );
}
