import React from 'react';
import { motion } from 'motion/react';
import { Quote } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      text: "Nous perdions beaucoup de demandes Instagram. Avec RAWR, chaque message reçoit une réponse rapide et les clientes sont guidées vers la réservation sans que l'on ait à intervenir.",
      author: "Marie D.",
      role: "Gérante, Salon de Beauté Placeholder",
      city: "Paris"
    },
    {
      text: "Le système anti no-show nous a fait gagner l'équivalent d'un salaire en évitant les annulations de dernière minute. Tout se fait tout seul par SMS et WhatsApp.",
      author: "Dr. L.",
      role: "Fondateur, Clinique Esthétique Placeholder",
      city: "Lyon"
    },
    {
      text: "Nos avis Google ont doublé en 2 mois. Le système envoie un message après la prestation pour demander un avis. Super simple et extrêmement efficace.",
      author: "Sophie T.",
      role: "Directrice, Institut Placeholder",
      city: "Bordeaux"
    }
  ];

  return (
    <section className="py-24 bg-rawr-bg">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        <div className="mb-16 text-center">
          <span className="text-xs max-w-sm mx-auto bg-rawr-ink/5 text-rawr-ink/60 px-3 py-1 rounded-full uppercase font-mono tracking-wider block mb-6">
            Espace réservé aux témoignages
          </span>
          <h2 className="text-3xl md:text-5xl font-serif">
            Ils automatisent déjà leur croissance.
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              key={i}
              className="bg-white p-8 rounded-[8px] border border-rawr-muted shadow-sm relative"
            >
              <Quote className="w-8 h-8 text-rawr-accent/20 absolute top-6 right-6" />
              <p className="text-sm leading-relaxed mb-8 italic text-rawr-ink/80 relative z-10">"{t.text}"</p>
              <div>
                <div className="font-bold text-sm">{t.author}</div>
                <div className="text-xs text-rawr-ink/60">
                  {t.role} • {t.city}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
