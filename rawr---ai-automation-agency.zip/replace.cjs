const fs = require('fs');
const files = [
  'src/components/PainPoints.tsx',
  'src/components/Transformation.tsx',
  'src/components/Solutions.tsx',
  'src/components/UseCases.tsx',
  'src/components/Benefits.tsx',
  'src/components/Offer.tsx',
  'src/components/LeadForm.tsx',
  'src/components/Testimonials.tsx',
  'src/components/FAQ.tsx',
  'src/components/FinalCTA.tsx',
];

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  content = content.replace(/rounded-3xl/g, 'rounded-[8px]');
  content = content.replace(/rounded-\[32px\]/g, 'rounded-[8px]');
  content = content.replace(/rounded-\[40px\]/g, 'rounded-[8px]');
  
  if (file.includes('Solutions') || file.includes('UseCases') || file.includes('Benefits') || file.includes('FAQ')) {
    content = content.replace(/rounded-2xl/g, 'rounded-[8px]');
  }
  
  if (file.includes('LeadForm')) {
    content = content.replace(/rounded-xl/g, 'rounded-[4px]');
  }

  if (file.includes('UseCases')) {
    content = content.replace(/rounded-xl/g, 'rounded-[8px]');
  }

  if (file.includes('Offer') || file.includes('FinalCTA')) {
    // Only the large button we want to change
    content = content.replace(/rounded-full text-lg/g, 'rounded-[4px] text-[12px] uppercase tracking-[0.5px]');
    content = content.replace(/rounded-full text-base/g, 'rounded-[4px] text-[12px] uppercase tracking-[0.5px]');
  }
  
  fs.writeFileSync(file, content);
});
console.log('replaced');
