import React from 'react';
import { Instagram, Linkedin, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-rawr-ink text-white/60 py-16 px-4 md:px-8 border-t border-white/10">
      <div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-12 mb-16">
        
        <div className="md:col-span-1">
          <h4 className="text-2xl font-serif font-bold text-white mb-4">RAWR</h4>
          <p className="text-sm font-light leading-relaxed mb-6">
            Agence d'automatisation IA pour cliniques esthétiques, salons et instituts en France.
          </p>
          <div className="flex items-center space-x-4">
            <a href="#" className="hover:text-white transition-colors" aria-label="Instagram"><Instagram size={20} /></a>
            <a href="#" className="hover:text-white transition-colors" aria-label="LinkedIn"><Linkedin size={20} /></a>
            <a href="#" className="hover:text-white transition-colors" aria-label="Twitter"><Twitter size={20} /></a>
          </div>
        </div>

        <div>
          <h5 className="text-white font-semibold mb-4 uppercase tracking-wider text-xs">Solutions</h5>
          <ul className="space-y-3 text-sm">
            <li><a href="#" className="hover:text-white transition-colors">Assistant Réservation AI</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Système Anti No-show</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Relances Automatisées</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Demande d'Avis Google</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Réactivation Clients</a></li>
          </ul>
        </div>

        <div>
          <h5 className="text-white font-semibold mb-4 uppercase tracking-wider text-xs">Société</h5>
          <ul className="space-y-3 text-sm">
            <li><a href="#processus" className="hover:text-white transition-colors">Méthode</a></li>
            <li><a href="#resultats" className="hover:text-white transition-colors">Résultats</a></li>
            <li><a href="#faq" className="hover:text-white transition-colors">FAQ</a></li>
            <li><a href="#audit" className="hover:text-white transition-colors">Audit Gratuit</a></li>
          </ul>
        </div>

        <div>
          <h5 className="text-white font-semibold mb-4 uppercase tracking-wider text-xs">Contact & Légal</h5>
          <ul className="space-y-3 text-sm">
            <li><a href="mailto:hello@rawr-automation.fr" className="hover:text-white transition-colors">hello@rawr-automation.fr</a></li>
            <li className="pt-4"><a href="#" className="hover:text-white transition-colors">Mentions légales</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Politique de confidentialité</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Gestion des cookies</a></li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between text-xs">
        <p>&copy; {new Date().getFullYear()} RAWR. Tous droits réservés.</p>
        <p className="mt-2 md:mt-0 italic opacity-50 text-center">Fait pour les cliniques et salons en France.</p>
      </div>
    </footer>
  );
}
