import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, MessageSquare, Calendar, Smartphone, RefreshCw } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
      {/* Decorative gradient blur background */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-rawr-accent/5 rounded-full blur-[120px] pointer-events-none transform translate-x-1/3 -translate-y-1/3" />
      <div className="absolute top-1/2 left-0 w-[400px] h-[400px] bg-rawr-ink/5 rounded-full blur-[100px] pointer-events-none transform -translate-x-1/2" />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="inline-flex items-center space-x-2 bg-white/60 backdrop-blur-sm border border-rawr-muted rounded-full px-4 py-2 mb-6">
              <span className="w-2 h-2 rounded-full bg-rawr-accent animate-pulse" />
              <span className="text-xs font-semibold uppercase tracking-wider text-rawr-ink/80">
                IA pour cliniques et salons
              </span>
            </div>
            
            <h1 className="text-[42px] font-serif leading-[1.1] font-normal text-rawr-ink mb-5">
              Automatisez votre clinique esthétique avec l’IA &mdash; <span className="text-rawr-accent italic">et remplissez votre agenda sans effort.</span>
            </h1>
            
            <p className="text-[16px] leading-[1.6] opacity-80 mb-[30px] max-w-xl">
              RAWR aide les cliniques esthétiques, salons de beauté et instituts en France à convertir plus de prospects, réduire les absences, relancer les clients automatiquement et augmenter les réservations grâce à des systèmes d’automatisation IA sur mesure.
            </p>
            
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 mb-10">
              <a
                href="#audit"
                className="inline-flex justify-center items-center px-5 py-2.5 rounded-[4px] text-[12px] font-semibold uppercase bg-rawr-accent text-white hover:opacity-90 transition-opacity"
              >
                Réserver un audit gratuit
              </a>
              <a
                href="#solutions"
                className="inline-flex justify-center items-center px-5 py-2.5 rounded-[4px] text-[12px] font-semibold uppercase text-rawr-ink border border-rawr-ink/20 hover:border-rawr-accent hover:text-rawr-accent transition-colors"
               >
                Découvrir les solutions
              </a>
            </div>

            <div className="grid grid-cols-2 gap-y-3 gap-x-8">
              {[
                "Installation rapide",
                "Automatisations sur mesure",
                "Conçu pour la France",
                "Moins de tâches manuelles"
              ].map((text, i) => (
                <div key={i} className="flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-rawr-accent" />
                  <span className="text-sm font-medium text-rawr-ink/70">{text}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Visualization / Mockup */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            {/* The Dashboard Mockup Container */}
            <div className="relative bg-[#151619] text-white border border-rawr-muted/50 rounded-[12px] shadow-2xl p-6 overflow-hidden">
               <div className="flex items-center justify-between mb-5 border-b border-[#2D2D2D] pb-[15px]">
                 <div className="text-[14px] font-semibold">Système RAWR - Live Dashboard</div>
                 <div className="text-[12px] opacity-70 flex items-center">
                   Status: <span className="w-2 h-2 rounded-full bg-[#22C55E] mx-1.5" />Opérationnel
                 </div>
               </div>

               <div className="space-y-4">
                 <DashboardActivity 
                   icon={<MessageSquare size={16} />}
                   title="Nouveau prospect (Instagram)"
                   desc="Message reçu : 'Prix pour soins visage ?'"
                   time="À l'instant"
                 />
                 <DashboardActivity 
                   icon={<RefreshCw size={16} />}
                   title="Qualification IA"
                   desc="Réponse automatique envoyée. Besoin identifié."
                   time="Il y a 1 min"
                   isActive
                 />
                 <DashboardActivity 
                   icon={<Calendar size={16} />}
                   title="Réservation automatique"
                   desc="RDV Soin Hydrafacial ce vendredi à 14h."
                   time="Il y a 2 min"
                 />
                 <DashboardActivity 
                   icon={<Smartphone size={16} />}
                   title="Confirmation & Rappel SMS"
                   desc="SMS envoyé à Sophie D."
                   time="Il y a 5 min"
                 />
               </div>
            </div>
            {/* Floating accent element */}
            <div className="absolute -bottom-6 -right-6 bg-rawr-accent text-white p-5 rounded-2xl shadow-xl max-w-xs transform rotate-2">
              <p className="text-sm font-semibold mb-1">Impact direct :</p>
              <p className="text-xs opacity-90">+32% de taux de conversion des messages en rendez-vous.</p>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}

function DashboardActivity({ icon, title, desc, time, isActive = false }: { icon: React.ReactNode, title: string, desc: string, time: string, isActive?: boolean }) {
  return (
    <div className={`p-[15px] rounded-[8px] flex items-start space-x-4 mb-3 bg-[#1F2124] border-l-[3px] ${isActive ? 'border-rawr-accent' : 'border-[#22C55E]'}`}>
      <div className="hidden">
        {icon}
      </div>
      <div className="flex-1">
        <div className="flex justify-between items-center mb-[5px]">
          <h4 className="text-[14px] text-white font-semibold m-0">{title}</h4>
          <span className="text-[11px] text-white/50">{time}</span>
        </div>
        <p className="text-[12px] text-[#9ca3af] m-0">{desc}</p>
      </div>
    </div>
  )
}
