import React, { useState, useEffect } from 'react';
import { Clock, MessageCircleOff, CalendarX, UserMinus, HardDrive, StarOff, CalendarOff, BrainCircuit } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function PainPoints() {
  const [currentIndex, setCurrentIndex] = useState(0);

  const painPoints = [
    {
      icon: <MessageCircleOff size={24} />,
      title: "Trop de prospects non relancés",
      desc: "Des demandes Instagram, WhatsApp ou email qui se perdent et coûtent des milliers d'euros."
    },
    {
      icon: <Clock size={24} />,
      title: "Appels et messages répétitifs",
      desc: "Vous répondez 10 fois par jour aux mêmes questions sur vos prix et disponibilités."
    },
    {
      icon: <CalendarX size={24} />,
      title: "Rendez-vous manqués (No-shows)",
      desc: "Des créneaux vides parce qu'un client a oublié de venir ou annulé à la dernière minute."
    },
    {
      icon: <UserMinus size={24} />,
      title: "Clients qui ne reviennent pas",
      desc: "Aucun suivi post-traitement organisé pour fidéliser ceux qui sont déjà venus."
    },
    {
      icon: <HardDrive size={24} />,
      title: "Canaux de communication éparpillés",
      desc: "Difficile de suivre qui a écrit où (Instagram, WhatsApp, site web) sans s'y perdre."
    },
    {
      icon: <StarOff size={24} />,
      title: "Avis Google insuffisants",
      desc: "Vos clientes sont ravies, mais vous oubliez (ou n'osez pas) leur demander un avis."
    },
    {
      icon: <CalendarOff size={24} />,
      title: "Agenda irrégulier",
      desc: "Des semaines pleines, suivies de semaines avec des trous impossibles à anticiper."
    },
    {
      icon: <BrainCircuit size={24} />,
      title: "Personnel débordé",
      desc: "Votre équipe fait de l'administratif au lieu de se concentrer sur l'expérience client."
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % painPoints.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="problemes" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-sm font-semibold uppercase tracking-wider text-rawr-accent mb-4 block">
            Le constat
          </span>
          <h2 className="text-3xl md:text-5xl font-serif mb-6 leading-tight">
            Votre équipe perd-elle du temps sur des tâches qui pourraient être automatisées ?
          </h2>
          <p className="text-lg text-rawr-ink/70">
            Gérer un salon ou une clinique esthétique demande déjà énormément d'énergie. Si en plus vous devez gérer manuellement les réservations et relances, vous perdez du temps et du chiffre d'affaires.
          </p>
        </div>

        {/* Desktop Grid */}
        <div className="hidden md:grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {painPoints.map((pt, i) => (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              key={i}
              className="group bg-white p-6 rounded-[12px] border border-rawr-muted hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
            >
              <div className="w-10 h-10 rounded-[8px] bg-rawr-accent/10 flex items-center justify-center text-rawr-accent mb-4 transition-colors duration-300 group-hover:bg-rawr-accent group-hover:text-white">
                {React.cloneElement(pt.icon as React.ReactElement, { size: 20 })}
              </div>
              <h3 className="text-[15px] font-bold mb-2 text-rawr-ink">{pt.title}</h3>
              <p className="text-rawr-ink/70 text-[13px] leading-relaxed m-0">{pt.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Mobile Slider */}
        <div className="md:hidden relative">
          <div className="overflow-hidden pb-8 px-2 mx-[-8px]">
            <motion.div 
              className="flex items-stretch"
              animate={{ x: `-${currentIndex * 100}%` }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
            >
              {painPoints.map((pt, i) => (
                <div key={i} className="w-full shrink-0 px-2 h-auto flex pb-4">
                  <div className="group flex-1 bg-white p-6 rounded-[12px] border border-rawr-muted shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 h-full flex flex-col">
                    <div className="w-10 h-10 rounded-[8px] bg-rawr-accent/10 flex items-center justify-center text-rawr-accent mb-4 transition-colors duration-300 group-hover:bg-rawr-accent group-hover:text-white">
                      {React.cloneElement(pt.icon as React.ReactElement, { size: 20 })}
                    </div>
                    <h3 className="text-[15px] font-bold mb-2 text-rawr-ink">{pt.title}</h3>
                    <p className="text-rawr-ink/70 text-[13px] leading-relaxed m-0 flex-grow">{pt.desc}</p>
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
          
          <div className="flex justify-center items-center space-x-2 mt-4">
            {painPoints.map((_, i) => (
              <button 
                key={i}
                onClick={() => setCurrentIndex(i)}
                className={`w-2 h-2 rounded-full transition-all duration-300 ${i === currentIndex ? 'bg-rawr-accent w-6' : 'bg-rawr-muted'}`}
                aria-label={`Go to slide ${i + 1}`}
              />
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
