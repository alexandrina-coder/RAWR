import React from 'react';
import { motion } from 'motion/react';

export default function Process() {
  const steps = [
    {
      num: "01",
      title: "Audit gratuit",
      desc: "Nous analysons votre parcours client, vos canaux actuels, vos pertes de prospects et vos tâches répétitives."
    },
    {
      num: "02",
      title: "Plan d'automatisation",
      desc: "Nous identifions les automatisations prioritaires pour augmenter les réservations et réduire les tâches manuelles."
    },
    {
      num: "03",
      title: "Installation RAWR",
      desc: "Nous construisons et connectons vos systèmes IA à vos outils existants (Instagram, WhatsApp, logiciel de caisse/agenda)."
    },
    {
      num: "04",
      title: "Optimisation continue",
      desc: "Nous suivons les performances, ajustons les messages et améliorons les workflows en permanence."
    }
  ];

  return (
    <section id="processus" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        <div className="mb-16">
          <h2 className="text-3xl md:text-5xl font-serif leading-tight">
            Comment se déroule la mise en place ?
          </h2>
        </div>

        <div className="grid md:grid-cols-4 gap-8 md:gap-4 relative">
          
          <div className="hidden md:block absolute top-[40px] left-8 right-8 h-px bg-rawr-ink/10" />

          {steps.map((step, i) => (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              key={i}
              className="relative relative z-10 bg-white"
            >
              <div className="w-20 h-20 bg-rawr-bg border border-rawr-muted rounded-full flex items-center justify-center text-2xl font-serif font-bold mb-6">
                {step.num}
              </div>
              <h3 className="text-xl font-bold mb-4">{step.title}</h3>
              <p className="text-rawr-ink/70 text-sm leading-relaxed">{step.desc}</p>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
