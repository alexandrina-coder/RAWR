import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Send } from 'lucide-react';

export default function LeadForm() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <section className="py-24 bg-white" id="formulaire">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-rawr-bg p-12 rounded-[8px] border border-rawr-muted"
          >
            <div className="w-20 h-20 bg-rawr-accent text-white rounded-full flex items-center justify-center mx-auto mb-6">
              <Send size={32} />
            </div>
            <h3 className="text-3xl font-serif mb-4">Demande envoyée</h3>
            <p className="text-rawr-ink/70">
              Merci. L'équipe RAWR a bien reçu votre demande d'audit gratuit. Nous reviendrons vers vous très rapidement pour préparer la session.
            </p>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-24 bg-white" id="formulaire">
      <div className="max-w-3xl mx-auto px-4">
        <h2 className="text-2xl md:text-4xl font-serif mb-8 text-center">Complétez le formulaire pour démarrer</h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">Nom complet *</label>
              <input required type="text" className="w-full p-[10px] rounded-[4px] border border-[#E5E5E5] bg-white text-[13px] focus:outline-none focus:border-rawr-accent focus:ring-1 focus:ring-rawr-accent" placeholder="Jean Dupont" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Nom de l’établissement *</label>
              <input required type="text" className="w-full p-[10px] rounded-[4px] border border-[#E5E5E5] bg-white text-[13px] focus:outline-none focus:border-rawr-accent focus:ring-1 focus:ring-rawr-accent" placeholder="Clinique Beauté" />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">Email *</label>
              <input required type="email" className="w-full p-[10px] rounded-[4px] border border-[#E5E5E5] bg-white text-[13px] focus:outline-none focus:border-rawr-accent focus:ring-1 focus:ring-rawr-accent" placeholder="jean@exemple.com" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Téléphone *</label>
              <input required type="tel" className="w-full p-[10px] rounded-[4px] border border-[#E5E5E5] bg-white text-[13px] focus:outline-none focus:border-rawr-accent focus:ring-1 focus:ring-rawr-accent" placeholder="06 12 34 56 78" />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">Ville *</label>
              <input required type="text" className="w-full p-[10px] rounded-[4px] border border-[#E5E5E5] bg-white text-[13px] focus:outline-none focus:border-rawr-accent focus:ring-1 focus:ring-rawr-accent" placeholder="Paris" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Type d’établissement *</label>
              <select required className="w-full p-[10px] rounded-[4px] border border-[#E5E5E5] bg-white text-[13px] focus:outline-none focus:border-rawr-accent focus:ring-1 focus:ring-rawr-accent">
                <option value="">Sélectionnez...</option>
                <option value="clinique">Clinique esthétique</option>
                <option value="salon">Salon de beauté</option>
                <option value="coiffure">Salon de coiffure</option>
                <option value="institut">Institut bien-être</option>
                <option value="autre">Autre</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Quel est votre principal objectif ? *</label>
            <select required className="w-full p-[10px] rounded-[4px] border border-[#E5E5E5] bg-white text-[13px] focus:outline-none focus:border-rawr-accent focus:ring-1 focus:ring-rawr-accent">
              <option value="">Sélectionnez...</option>
              <option value="rdv">Plus de rendez-vous</option>
              <option value="noshow">Moins de no-shows</option>
              <option value="automatiser">Automatiser les messages</option>
              <option value="reactiver">Réactiver les anciens clients</option>
              <option value="avis">Améliorer les avis Google</option>
              <option value="autre">Autre</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Message libre (optionnel)</label>
            <textarea rows={4} className="w-full p-[10px] rounded-[4px] border border-[#E5E5E5] bg-white text-[13px] focus:outline-none focus:border-rawr-accent focus:ring-1 focus:ring-rawr-accent" placeholder="Dites-nous en plus sur votre situation actuelle..." />
          </div>

          <div className="text-center pt-4">
            <button type="submit" className="w-full bg-rawr-accent text-white p-[14px] rounded-[4px] text-[12px] font-semibold uppercase hover:bg-rawr-accent/90 transition-colors">
              Recevoir mon audit gratuit
            </button>
            <p className="text-xs text-rawr-ink/50 mt-4">En soumettant ce formulaire, vous acceptez d'être contacté par RAWR.</p>
          </div>
        </form>

      </div>
    </section>
  );
}
