import React from 'react';
import { motion } from 'motion/react';
import { Check } from 'lucide-react';

export default function Offer() {
  return (
    <section id="audit" className="py-24 bg-rawr-bg pt-32">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-5xl font-serif mb-8 leading-tight">
          Commencez par un audit gratuit de votre parcours client.
        </h2>
        
        <div className="bg-white rounded-[8px] p-8 md:p-12 border border-rawr-muted shadow-xl text-left relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-rawr-accent/5 rounded-full blur-[80px]" />
          
          <div className="grid md:grid-cols-2 gap-12 relative z-10">
            <div>
              <div className="inline-block bg-rawr-accent text-white text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-6">
                Audit Gratuit RAWR
              </div>
              <h3 className="text-2xl font-serif font-bold mb-4">
                Découvrez combien de réservations vous perdez actuellement.
              </h3>
              <p className="text-rawr-ink/70 text-sm mb-6">
                Réservé aux cliniques esthétiques, salons et instituts en France. Places limitées chaque mois pour garantir une analyse personnalisée.
              </p>
              
              <ul className="space-y-4 mb-8">
                {[
                  "Analyse de votre système de réservation",
                  "Identification des pertes de prospects",
                  "Audit de vos relances actuelles",
                  "Recommandations d'automatisations IA",
                  "Plan d'action personnalisé"
                ].map((item, i) => (
                  <li key={i} className="flex items-center space-x-3">
                    <Check className="w-5 h-5 text-rawr-accent" />
                    <span className="text-sm font-medium">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="flex items-center justify-center">
              <a
                href="#formulaire"
                className="w-full sm:w-auto text-center inline-block bg-rawr-ink text-white px-8 py-5 rounded-[4px] text-[12px] uppercase tracking-[0.5px] font-medium hover:bg-rawr-accent transition-colors shadow-xl"
              >
                Réserver mon audit
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
