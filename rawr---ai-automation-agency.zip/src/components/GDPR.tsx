import React from 'react';
import { ShieldCheck, Lock, FileText, Settings2 } from 'lucide-react';

export default function GDPR() {
  return (
    <section className="py-16 bg-rawr-bg border-y border-rawr-muted/50">
      <div className="max-w-7xl mx-auto px-4 md:px-8 text-center">
        
        <h2 className="text-xl font-serif mb-12 italic text-rawr-ink/80">Pensé pour le marché français.</h2>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-5xl mx-auto">
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-rawr-accent mb-4 shadow-sm border border-rawr-muted">
              <ShieldCheck size={20} />
            </div>
            <span className="text-sm font-medium">Respect RGPD</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-rawr-accent mb-4 shadow-sm border border-rawr-muted">
              <Lock size={20} />
            </div>
            <span className="text-sm font-medium">Données Sécurisées</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-rawr-accent mb-4 shadow-sm border border-rawr-muted">
              <FileText size={20} />
            </div>
            <span className="text-sm font-medium">Transparence IA</span>
          </div>
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-rawr-accent mb-4 shadow-sm border border-rawr-muted">
              <Settings2 size={20} />
            </div>
            <span className="text-sm font-medium">Ton adaptable</span>
          </div>
        </div>

      </div>
    </section>
  );
}
