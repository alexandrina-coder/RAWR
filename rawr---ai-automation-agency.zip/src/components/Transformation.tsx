import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, XCircle, CheckCircle } from 'lucide-react';

export default function Transformation() {
  const beforeList = [
    "Prospects oubliés après 24h",
    "Relances effectuées manuellement",
    "Agenda instable selon les semaines",
    "No-shows fréquents (≈15-20%)",
    "Avis clients rarement demandés",
    "Équipe débordée par le téléphone"
  ];

  const afterList = [
    "Réponses instantanées par IA (24/7)",
    "Relances intelligentes automatisées",
    "Réservations fluides et qualifiées",
    "Rappels intelligents (SMS/WhatsApp)",
    "Avis Google générés sur pilote auto",
    "Équipe concentrée sur l'expérience client"
  ];

  return (
    <section className="py-24 bg-rawr-ink text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-5xl font-serif mb-6 leading-tight">
            RAWR transforme votre parcours client en <span className="italic text-rawr-accent-light">système automatisé.</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-[1fr_auto_1fr] gap-8 items-center max-w-5xl mx-auto">
          
          {/* Before */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-white/5 border border-white/10 rounded-[8px] p-8 md:p-12"
          >
            <h3 className="text-xl font-bold mb-8 flex items-center space-x-3 opacity-60">
              <span>Avant RAWR</span>
            </h3>
            <ul className="space-y-6">
              {beforeList.map((item, i) => (
                <li key={i} className="flex items-start space-x-4 opacity-60">
                  <XCircle className="w-6 h-6 text-red-400 shrink-0" />
                  <span className="text-sm md:text-base">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          <div className="flex justify-center rotate-90 lg:rotate-0 my-4 lg:my-0">
            <ArrowRight className="w-12 h-12 text-rawr-accent-light opacity-50" />
          </div>

          {/* After */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-rawr-accent/20 border border-rawr-accent/30 rounded-[8px] p-8 md:p-12 relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-rawr-accent rounded-full blur-[100px] opacity-20 pointer-events-none" />
            
            <h3 className="text-xl font-bold mb-8 flex items-center space-x-3">
              <span>Avec RAWR</span>
            </h3>
            <ul className="space-y-6 relative z-10">
              {afterList.map((item, i) => (
                <li key={i} className="flex items-start space-x-4">
                  <CheckCircle className="w-6 h-6 text-rawr-accent-light shrink-0" />
                  <span className="text-sm md:text-base font-medium">{item}</span>
                </li>
              ))}
            </ul>
          </motion.div>

        </div>
      </div>
    </section>
  );
}
