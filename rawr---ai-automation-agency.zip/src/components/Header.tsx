import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Accueil', href: '#home' },
    { name: 'Problèmes', href: '#problemes' },
    { name: 'Solutions IA', href: '#solutions' },
    { name: 'Résultats', href: '#resultats' },
    { name: 'Processus', href: '#processus' },
    { name: 'FAQ', href: '#faq' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-rawr-bg/90 backdrop-blur-md shadow-sm py-4' : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-between">
        <a href="#home" className="text-[28px] font-serif font-black text-rawr-accent tracking-[1px]">
          RAWR
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-[13px] font-medium uppercase tracking-[0.5px] text-rawr-ink/80 hover:text-rawr-accent transition-colors"
            >
              {link.name}
            </a>
          ))}
          <a
            href="#audit"
            className="bg-rawr-accent text-white px-5 py-2.5 rounded-[4px] text-[12px] font-semibold uppercase transition-colors"
          >
            Réserver un audit gratuit
          </a>
        </nav>

        {/* Mobile menu button */}
        <button
          className="md:hidden text-rawr-ink"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.nav
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 right-0 bg-rawr-surface shadow-lg border-t border-rawr-muted/30 p-4 md:hidden flex flex-col space-y-4"
          >
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-[13px] font-medium uppercase tracking-[0.5px] text-rawr-ink/90 p-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <a
              href="#audit"
              onClick={() => setIsMobileMenuOpen(false)}
              className="bg-rawr-accent text-white px-5 py-3 rounded-[4px] text-[12px] uppercase font-semibold text-center mt-4"
            >
              Réserver un audit gratuit
            </a>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
